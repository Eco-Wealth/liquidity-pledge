# ACTION_ENCODING — Uniswap v4 PositionManager calldata (v0)

PositionManager is command-batched; mint and collect are encoded as `(bytes actions, bytes[] params)` inside unlockData.
PositionManager guide: https://docs.uniswap.org/contracts/v4/guides/position-manager
Mint quickstart: https://docs.uniswap.org/contracts/v4/quickstart/manage-liquidity/mint-position
Collect quickstart: https://docs.uniswap.org/contracts/v4/quickstart/manage-liquidity/collect

## Mint (default: ERC20/ERC20, full-range, 1% fee)
Actions:
- MINT_POSITION
- SETTLE_PAIR
(optional SWEEP only for ETH liquidity)

The mint quickstart explicitly states these actions and shows `abi.encodePacked(uint8(Actions.MINT_POSITION), uint8(Actions.SETTLE_PAIR))`.
https://docs.uniswap.org/contracts/v4/quickstart/manage-liquidity/mint-position

Params:
- MINT_POSITION params: see CalldataDecoder decodeMintParams signature:
  https://docs.uniswap.org/contracts/v4/reference/periphery/libraries/CalldataDecoder
- SETTLE_PAIR params: `abi.encode(currency0, currency1)` per quickstart.

## Collect fees (Option B)
Actions:
- DECREASE_LIQUIDITY (liquidity=0)  // “zero-liquidity decrease” fee sweep
- TAKE_PAIR (recipient=feeRecipient)

Collect quickstart shows this exact action sequence and encoding.
https://docs.uniswap.org/contracts/v4/quickstart/manage-liquidity/collect

SDK guide confirms `DECREASE_LIQUIDITY(liquidity=0)+TAKE_PAIR` under the hood.
https://docs.uniswap.org/sdk/v4/guides/liquidity/collect-fees
