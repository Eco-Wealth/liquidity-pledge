# SPEC — EcoWealth $1 Liquidity Pledge (v0)

## Constants
- Chain: Base (8453)
- ecowealth ERC20 (Base): 0x170dc0ca26f1247ced627d8abcafa90ecf1e1519

## Invariants
1) Whitelist-only: pledge reverts unless approvedPartnerToken[token] == true.
2) Cap in ecowealth units: ecoMatched <= capEcoWei[token]. No oracle in v0.
3) Partner side is single-tx using Permit2 `permitWitnessTransferFrom` (no ERC20 approve required).
   https://docs.uniswap.org/contracts/permit2/reference/signature-transfer
4) Router matches ecowealth from MATCH_WALLET via standard ERC20 allowance.
5) Mint LP via Uniswap v4 PositionManager batching `modifyLiquidities(unlockData, deadline)`.
   https://docs.uniswap.org/contracts/v4/guides/position-manager
6) LP principal locked forever: minted ERC721 tokenId is transferred to LockVault.
7) LockVault has NO function to transfer NFT out, and NO function to decrease liquidity.
8) Fees claimable only by feeRecipient[tokenId], via v4 actions:
   DECREASE_LIQUIDITY(liquidity=0) + TAKE_PAIR(recipient).
   https://docs.uniswap.org/contracts/v4/quickstart/manage-liquidity/collect
   https://docs.uniswap.org/sdk/v4/guides/liquidity/collect-fees
9) Router pause/unpause: when paused, pledge is disabled.
10) Router rescueERC20: may rescue non-ecowealth ERC20 mistakenly sent to Router; never rescue from LockVault; never rescue ecowealth.

## TokenId determination (v0)
Router reads `PositionManager.nextTokenId()` immediately before mint and uses it as tokenId.
PositionManager reference: https://docs.uniswap.org/contracts/v4/reference/periphery/PositionManager

## Revisit before ship (hard gate)
- Fill Base v4 addresses from https://docs.uniswap.org/contracts/v4/deployments
- Replace placeholder actions/params with v4-periphery Actions.sol + exact param encoders:
  https://github.com/Uniswap/v4-periphery
- Add Base fork tests.
