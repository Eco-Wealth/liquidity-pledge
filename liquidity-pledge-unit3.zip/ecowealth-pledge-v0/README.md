# EcoWealth $1 Liquidity Pledge (v0)

Whitelist-only pledge system that:
1) pulls partner tokens via Permit2 witness signature (single-tx UX),
2) matches with ecowealth from a separate MATCH_WALLET allowance,
3) mints a Uniswap v4 PositionManager LP NFT (default 1% fee, full-range),
4) locks the LP NFT principal forever in a LockVault,
5) allows only a designated feeRecipient to collect fees via v4's documented pattern.

Authoritative docs:
- Permit2 witness signature transfer: https://docs.uniswap.org/contracts/permit2/reference/signature-transfer
- PositionManager batching: https://docs.uniswap.org/contracts/v4/guides/position-manager
- Mint position (MINT_POSITION + SETTLE_PAIR; optional SWEEP): https://docs.uniswap.org/contracts/v4/quickstart/manage-liquidity/mint-position
- Collect fees (DECREASE_LIQUIDITY + TAKE_PAIR): https://docs.uniswap.org/contracts/v4/quickstart/manage-liquidity/collect
- SDK collect-fees explanation (DECREASE_LIQUIDITY(0)+TAKE_PAIR): https://docs.uniswap.org/sdk/v4/guides/liquidity/collect-fees
- v4 deployments (fill Base addresses at ship time): https://docs.uniswap.org/contracts/v4/deployments
- v4-periphery repo: https://github.com/Uniswap/v4-periphery
- Permit2 repo: https://github.com/Uniswap/permit2

## Status
This repo is a **v0 scaffold**: it compiles and passes unit tests using mocks.
Before shipping, replace mocks with real Permit2 + v4-periphery action encoding and add Base fork tests.

## Quickstart (unit tests, mocks)
```bash
forge test -vvv
```

## Ship-time hard gate
1) Fill Base addresses from https://docs.uniswap.org/contracts/v4/deployments (PositionManager, PoolManager, Permit2)
2) Replace mock action encoding with v4-periphery Actions encoding in `src/libraries/V4ActionBuilder.sol`
3) Add Base fork tests that hit real `PositionManager.modifyLiquidities`
4) Set ADMIN to a Safe; set MATCH_WALLET to a separate Safe funded with ecowealth and approve Router
